# Alice 2022
Alice aiml chatbot for java on linux and unix systems. WARNING This was created with the idea of total free speech. If you are not 18 years old,
please run something else. Alice loves to hear it straight. That means say how you really feel. She will know if you are not. 
to unzip the file you must first create a single file using cat try
cat * > alice.zip (from the correct directory of course)
then unzip it using whatever like zip perhaps
- credits - Doctor Wallace & MIT in Boston
