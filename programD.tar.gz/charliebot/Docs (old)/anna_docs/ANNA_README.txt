So you've downloaded Anna. What now?

First off, make sure you have Java 2 1.4. You can download it from java.sun.com, and its needed to run the AIML Interpreter. You can check by running "java -version" from the command line.

After that, take a gander at the included documentation, in the anna_docs/ folder. It contains information regarding executing and editing the program. In short, execute run.bat (Windows) or server.sh (Linux or OS X).

Please help by making edits to files if you think you can improve Anna's responses.

Send an email if youve got questions, concerns, problems, or youd like to help with this very cool project.
aothman@umich.edu

Version .6.1/September 27, 2002

***Anna is now  semi-finalist in the 2002 Loebner Prize Competition***
