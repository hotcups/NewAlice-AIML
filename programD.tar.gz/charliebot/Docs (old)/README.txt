These docs are here for historical significance and General help. They are, for the most part, outdated but still provide some helpful reading material.

On the one hand, there is the Program D documents. Program D is at the root of all later developments.

On the other hand, there is the Anna documents. Anna is what Charlie is directly descended from.